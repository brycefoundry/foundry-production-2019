/* Dump of database wp_foundry on foundry-prd:8888 at 2018-12-13 20:09:14 */

/* Table structure for table `wp_commentmeta` */

DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/* Table structure for table `wp_comments` */

DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/* dumping data for table `wp_comments` */
INSERT INTO `wp_comments` VALUES
('1','1','A WordPress Commenter','wapuu@wordpress.example','https://wordpress.org/','','2018-12-09 02:57:46','2018-12-09 02:57:46','Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.','0','1','','','0','0');

/* Table structure for table `wp_links` */

DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/* Table structure for table `wp_options` */

DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8;

/* dumping data for table `wp_options` */
INSERT INTO `wp_options` VALUES
('1','siteurl','http://foundry-prd:8888','yes'),
('2','home','http://foundry-prd:8888','yes'),
('3','blogname','Foundry ATX | Strategy &amp; Creative Services','yes'),
('4','blogdescription','Digital strategy &amp; full-service design studio based in Austin, Texas','yes'),
('5','users_can_register','0','yes'),
('6','admin_email','bryce@foundrydigital.co','yes'),
('7','start_of_week','1','yes'),
('8','use_balanceTags','0','yes'),
('9','use_smilies','1','yes'),
('10','require_name_email','1','yes'),
('11','comments_notify','1','yes'),
('12','posts_per_rss','10','yes'),
('13','rss_use_excerpt','0','yes'),
('14','mailserver_url','mail.example.com','yes'),
('15','mailserver_login','login@example.com','yes'),
('16','mailserver_pass','password','yes'),
('17','mailserver_port','110','yes'),
('18','default_category','1','yes'),
('19','default_comment_status','open','yes'),
('20','default_ping_status','open','yes'),
('21','default_pingback_flag','1','yes'),
('22','posts_per_page','10','yes'),
('23','date_format','F j, Y','yes'),
('24','time_format','g:i a','yes'),
('25','links_updated_date_format','F j, Y g:i a','yes'),
('26','comment_moderation','0','yes'),
('27','moderation_notify','1','yes'),
('28','permalink_structure','/{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}postname{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}/','yes'),
('30','hack_file','0','yes'),
('31','blog_charset','UTF-8','yes'),
('32','moderation_keys','','no'),
('33','active_plugins','a:11:{i:0;s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";i:1;s:34:\"advanced-custom-fields-pro/acf.php\";i:2;s:47:\"bootstrap-3-shortcodes/bootstrap-shortcodes.php\";i:3;s:33:\"classic-editor/classic-editor.php\";i:4;s:31:\"database-sync/database-sync.php\";i:5;s:15:\"drift/drift.php\";i:6;s:46:\"facebook-thumb-fixer/_facebook-thumb-fixer.php\";i:7;s:25:\"livereload/livereload.php\";i:8;s:23:\"tag-pages/tag-pages.php\";i:9;s:41:\"wordpress-importer/wordpress-importer.php\";i:10;s:24:\"wordpress-seo/wp-seo.php\";}','yes'),
('34','category_base','','yes'),
('35','ping_sites','http://rpc.pingomatic.com/','yes'),
('36','comment_max_links','2','yes'),
('37','gmt_offset','0','yes'),
('38','default_email_category','1','yes'),
('39','recently_edited','','no'),
('40','template','foundry-2019','yes'),
('41','stylesheet','foundry-2019','yes'),
('42','comment_whitelist','1','yes'),
('43','blacklist_keys','','no'),
('44','comment_registration','0','yes'),
('45','html_type','text/html','yes'),
('46','use_trackback','0','yes'),
('47','default_role','subscriber','yes'),
('48','db_version','43764','yes'),
('49','uploads_use_yearmonth_folders','1','yes'),
('50','upload_path','','yes'),
('51','blog_public','1','yes'),
('52','default_link_category','2','yes'),
('53','show_on_front','posts','yes'),
('54','tag_base','','yes'),
('55','show_avatars','1','yes'),
('56','avatar_rating','G','yes'),
('57','upload_url_path','','yes'),
('58','thumbnail_size_w','150','yes'),
('59','thumbnail_size_h','150','yes'),
('60','thumbnail_crop','1','yes'),
('61','medium_size_w','300','yes'),
('62','medium_size_h','300','yes'),
('63','avatar_default','mystery','yes'),
('64','large_size_w','1024','yes'),
('65','large_size_h','1024','yes'),
('66','image_default_link_type','none','yes'),
('67','image_default_size','','yes'),
('68','image_default_align','','yes'),
('69','close_comments_for_old_posts','0','yes'),
('70','close_comments_days_old','14','yes'),
('71','thread_comments','1','yes'),
('72','thread_comments_depth','5','yes'),
('73','page_comments','0','yes'),
('74','comments_per_page','50','yes'),
('75','default_comments_page','newest','yes'),
('76','comment_order','asc','yes'),
('77','sticky_posts','a:0:{}','yes'),
('78','widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),
('79','widget_text','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),
('80','widget_rss','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),
('81','uninstall_plugins','a:2:{s:23:\"drift/includes/core.php\";s:15:\"Drift_uninstall\";s:33:\"classic-editor/classic-editor.php\";a:2:{i:0;s:14:\"Classic_Editor\";i:1;s:9:\"uninstall\";}}','no'),
('82','timezone_string','','yes'),
('83','page_for_posts','0','yes'),
('84','page_on_front','0','yes'),
('85','default_post_format','0','yes'),
('86','link_manager_enabled','0','yes'),
('87','finished_splitting_shared_terms','1','yes'),
('88','site_icon','0','yes'),
('89','medium_large_size_w','768','yes'),
('90','medium_large_size_h','0','yes'),
('91','wp_page_for_privacy_policy','3','yes'),
('92','show_comments_cookies_opt_in','0','yes'),
('93','initial_db_version','43764','yes'),
('94','wp_user_roles','a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}}','yes'),
('95','fresh_site','0','yes'),
('96','widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),
('97','widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),
('98','widget_recent-comments','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),
('99','widget_archives','a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),
('100','widget_meta','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),
('101','sidebars_widgets','a:4:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"widget-area-1\";a:0:{}s:13:\"widget-area-2\";a:0:{}s:13:\"array_version\";i:3;}','yes'),
('102','widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
('103','widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
('104','widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
('105','widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
('106','widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
('107','widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
('108','nonce_key','Yl)~B}>f+5,YDXjx6gf/,g ehml`,(-41&UUXy/pF(G|FnEJ`9=^azN+h?Y/&gJa','no'),
('109','nonce_salt','REj29LFto|<jz0 S5L+k7^p:>.XLe}BCEV<NI`yiw= [PnL}dx#~]{0Ue9gJ`_d^','no'),
('110','widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
('111','widget_nav_menu','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
('112','widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),
('113','cron','a:6:{i:1544734669;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1544756269;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1544756330;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1544756471;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1544759577;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}','yes'),
('115','auth_key','v_Z@0T)<}P{(zU}vj`A.cVZnmjDdVwx^(d^*EZ<QqLRID2h.`y7k<9bS?!#{MRvH','no'),
('116','auth_salt','#?~mTI{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}k.e;LWQ}D$R]O<V$ZlAnB|S2q}l.)Y>sM|yC?Qms`Q#G- d#;Xh7EkAD{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}','no'),
('117','logged_in_key','5H(&dOS$IWD?+HXTl!C*W#|kHM}l8Y])XpK{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}g{>8o50qt/;Y0&>z0f-+aD~e$A6n','no'),
('118','logged_in_salt','pyv*Pcy>Yr2N2BcPYKg_!o:o^uE1Iv{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}BDMgTbMFt`!`kQbWA0&jyoD]f=R-bd@rL','no'),
('119','_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.1-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-5.0.1-partial-0.zip\";s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.1\";s:7:\"version\";s:5:\"5.0.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:3:\"5.0\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.1-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-5.0.1-partial-0.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.1-rollback-0.zip\";}s:7:\"current\";s:5:\"5.0.1\";s:7:\"version\";s:5:\"5.0.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:3:\"5.0\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1544731691;s:15:\"version_checked\";s:3:\"5.0\";s:12:\"translations\";a:0:{}}','no'),
('123','_site_transient_update_themes','O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1544731694;s:7:\"checked\";a:1:{s:12:\"foundry-2019\";s:5:\"1.4.3\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}','no'),
('124','_site_transient_timeout_browser_35492a2c37ba590972f9a97b57ea7ece','1544929132','no'),
('125','_site_transient_browser_35492a2c37ba590972f9a97b57ea7ece','a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"70.0.3538.110\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}','no'),
('126','can_compress_scripts','1','no'),
('139','theme_mods_twentynineteen','a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1544324352;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}','yes'),
('140','current_theme','HTML5 Blank','yes'),
('141','theme_mods_foundry-2019','a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}','yes'),
('142','theme_switched','','yes'),
('145','recently_activated','a:0:{}','yes'),
('152','wpseo','a:19:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:5:\"9.0.3\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1544324471;}','yes'),
('153','wpseo_titles','a:77:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitedesc{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:18:\"title-author-wpseo\";s:41:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}name{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}, Author at {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:19:\"title-archive-wpseo\";s:38:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}date{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:18:\"title-search-wpseo\";s:63:\"You searched for {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}searchphrase{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:15:\"title-404-wpseo\";s:35:\"Page not found {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}POSTLINK{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} appeared first on {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}BLOGLINK{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:0:\"\";s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}title{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:10:\"title-page\";s:39:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}title{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";i:0;s:16:\"title-attachment\";s:39:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}title{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";i:0;s:17:\"title-html5-blank\";s:39:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}title{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:20:\"metadesc-html5-blank\";s:0:\"\";s:19:\"noindex-html5-blank\";b:0;s:20:\"showdate-html5-blank\";b:0;s:30:\"display-metabox-pt-html5-blank\";b:1;s:30:\"post_types-html5-blank-maintax\";i:0;s:27:\"title-ptarchive-html5-blank\";s:51:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}pt_plural{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} Archive {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:30:\"metadesc-ptarchive-html5-blank\";s:0:\"\";s:29:\"bctitle-ptarchive-html5-blank\";s:0:\"\";s:29:\"noindex-ptarchive-html5-blank\";b:0;s:18:\"title-tax-category\";s:53:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}term_title{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} Archives {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}term_title{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} Archives {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}term_title{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} Archives {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}page{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sep{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51} {2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}sitename{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;}','yes'),
('154','wpseo_social','a:20:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}','yes'),
('155','wpseo_flush_rewrite','1','yes'),
('156','_transient_timeout_wpseo_link_table_inaccessible','1575860471','no'),
('157','_transient_wpseo_link_table_inaccessible','0','no'),
('158','_transient_timeout_wpseo_meta_table_inaccessible','1575860471','no'),
('159','_transient_wpseo_meta_table_inaccessible','0','no'),
('160','acf_version','5.7.8','yes'),
('163','WPLANG','','yes'),
('164','new_admin_email','bryce@foundrydigital.co','yes'),
('165','default_fb_thumb','','yes'),
('166','fb_app_ID','','yes'),
('167','homepage_object_type','','yes'),
('178','rewrite_rules','a:130:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:10:\"clients/?$\";s:27:\"index.php?post_type=clients\";s:40:\"clients/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=clients&feed=$matches[1]\";s:35:\"clients/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=clients&feed=$matches[1]\";s:27:\"clients/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=clients&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:32:\"work/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"work/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"work/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"work/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"work/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"work/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"work/([^/]+)/embed/?$\";s:37:\"index.php?work=$matches[1]&embed=true\";s:25:\"work/([^/]+)/trackback/?$\";s:31:\"index.php?work=$matches[1]&tb=1\";s:33:\"work/([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?work=$matches[1]&paged=$matches[2]\";s:40:\"work/([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?work=$matches[1]&cpage=$matches[2]\";s:29:\"work/([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?work=$matches[1]&page=$matches[2]\";s:21:\"work/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"work/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"work/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"work/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"work/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"work/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:35:\"clients/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"clients/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"clients/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"clients/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"clients/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"clients/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"clients/([^/]+)/embed/?$\";s:40:\"index.php?clients=$matches[1]&embed=true\";s:28:\"clients/([^/]+)/trackback/?$\";s:34:\"index.php?clients=$matches[1]&tb=1\";s:48:\"clients/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?clients=$matches[1]&feed=$matches[2]\";s:43:\"clients/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?clients=$matches[1]&feed=$matches[2]\";s:36:\"clients/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?clients=$matches[1]&paged=$matches[2]\";s:43:\"clients/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?clients=$matches[1]&cpage=$matches[2]\";s:32:\"clients/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?clients=$matches[1]&page=$matches[2]\";s:24:\"clients/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"clients/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"clients/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"clients/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"clients/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"clients/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}','yes'),
('187','outlandish_sync_secret','l#OezGq$=M,{G?Mw','yes'),
('188','outlandish_sync_tokens','a:1:{s:30:\"https://staging.foundryatx.com\";s:16:\"`k&BZLW03}@d\\6^0\";}','yes'),
('193','acf_pro_license','YToyOntzOjM6ImtleSI7czo3NjoiYjNKa1pYSmZhV1E5TVRJME16Z3lmSFI1Y0dVOVpHVjJaV3h2Y0dWeWZHUmhkR1U5TWpBeE9DMHdNaTB3T0NBeE5Ub3lNem95Tmc9PSI7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODg4OCI7fQ==','yes'),
('208','category_children','a:0:{}','yes'),
('236','_transient_timeout_acf_plugin_updates','1544818093','no'),
('237','_transient_acf_plugin_updates','a:4:{s:7:\"plugins\";a:0:{}s:10:\"expiration\";i:86400;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.7.8\";}}','no'),
('238','_site_transient_timeout_theme_roots','1544733493','no'),
('239','_site_transient_theme_roots','a:1:{s:12:\"foundry-2019\";s:7:\"/themes\";}','no'),
('240','_site_transient_update_plugins','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1544731694;s:7:\"checked\";a:11:{s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";s:5:\"2.1.0\";s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.7.8\";s:47:\"bootstrap-3-shortcodes/bootstrap-shortcodes.php\";s:6:\"3.3.12\";s:33:\"classic-editor/classic-editor.php\";s:3:\"1.2\";s:31:\"database-sync/database-sync.php\";s:5:\"0.5.1\";s:15:\"drift/drift.php\";s:5:\"1.8.4\";s:25:\"livereload/livereload.php\";s:3:\"2.0\";s:23:\"tag-pages/tag-pages.php\";s:5:\"1.0.1\";s:46:\"facebook-thumb-fixer/_facebook-thumb-fixer.php\";s:5:\"1.7.6\";s:41:\"wordpress-importer/wordpress-importer.php\";s:5:\"0.6.4\";s:24:\"wordpress-seo/wp-seo.php\";s:5:\"9.0.3\";}s:8:\"response\";a:2:{s:33:\"classic-editor/classic-editor.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:28:\"w.org/plugins/classic-editor\";s:4:\"slug\";s:14:\"classic-editor\";s:6:\"plugin\";s:33:\"classic-editor/classic-editor.php\";s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/classic-editor/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/classic-editor.1.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-256x256.png?rev=1750045\";s:2:\"1x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-128x128.png?rev=1750045\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/classic-editor/assets/banner-1544x500.png?rev=1750404\";s:2:\"1x\";s:69:\"https://ps.w.org/classic-editor/assets/banner-772x250.png?rev=1751803\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.0.1\";s:12:\"requires_php\";s:5:\"5.2.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:5:\"9.2.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/wordpress-seo.9.2.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}s:6:\"tested\";s:3:\"5.0\";s:12:\"requires_php\";s:5:\"5.2.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:8:{s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:48:\"w.org/plugins/acf-content-analysis-for-yoast-seo\";s:4:\"slug\";s:34:\"acf-content-analysis-for-yoast-seo\";s:6:\"plugin\";s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";s:11:\"new_version\";s:5:\"2.1.0\";s:3:\"url\";s:65:\"https://wordpress.org/plugins/acf-content-analysis-for-yoast-seo/\";s:7:\"package\";s:83:\"https://downloads.wordpress.org/plugin/acf-content-analysis-for-yoast-seo.2.1.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:87:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/icon-256x256.png?rev=1717503\";s:2:\"1x\";s:87:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/icon-128x128.png?rev=1717503\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:90:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/banner-1544x500.png?rev=1717503\";s:2:\"1x\";s:89:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/banner-772x250.png?rev=1717503\";}s:11:\"banners_rtl\";a:0:{}}s:47:\"bootstrap-3-shortcodes/bootstrap-shortcodes.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/bootstrap-3-shortcodes\";s:4:\"slug\";s:22:\"bootstrap-3-shortcodes\";s:6:\"plugin\";s:47:\"bootstrap-3-shortcodes/bootstrap-shortcodes.php\";s:11:\"new_version\";s:6:\"3.3.12\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/bootstrap-3-shortcodes/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/bootstrap-3-shortcodes.3.3.12.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:67:\"https://ps.w.org/bootstrap-3-shortcodes/assets/icon.svg?rev=1010631\";s:3:\"svg\";s:67:\"https://ps.w.org/bootstrap-3-shortcodes/assets/icon.svg?rev=1010631\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/bootstrap-3-shortcodes/assets/banner-1544x500.png?rev=861867\";s:2:\"1x\";s:76:\"https://ps.w.org/bootstrap-3-shortcodes/assets/banner-772x250.png?rev=861867\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"database-sync/database-sync.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/database-sync\";s:4:\"slug\";s:13:\"database-sync\";s:6:\"plugin\";s:31:\"database-sync/database-sync.php\";s:11:\"new_version\";s:5:\"0.5.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/database-sync/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/database-sync.0.5.1.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:57:\"https://s.w.org/plugins/geopattern-icon/database-sync.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:15:\"drift/drift.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:19:\"w.org/plugins/drift\";s:4:\"slug\";s:5:\"drift\";s:6:\"plugin\";s:15:\"drift/drift.php\";s:11:\"new_version\";s:5:\"1.8.4\";s:3:\"url\";s:36:\"https://wordpress.org/plugins/drift/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/drift.1.8.4.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:58:\"https://ps.w.org/drift/assets/icon-256x256.png?rev=1414337\";s:2:\"1x\";s:50:\"https://ps.w.org/drift/assets/icon.svg?rev=1504629\";s:3:\"svg\";s:50:\"https://ps.w.org/drift/assets/icon.svg?rev=1504629\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/drift/assets/banner-1544x500.png?rev=1414337\";s:2:\"1x\";s:60:\"https://ps.w.org/drift/assets/banner-772x250.png?rev=1414337\";}s:11:\"banners_rtl\";a:0:{}}s:25:\"livereload/livereload.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:24:\"w.org/plugins/livereload\";s:4:\"slug\";s:10:\"livereload\";s:6:\"plugin\";s:25:\"livereload/livereload.php\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/livereload/\";s:7:\"package\";s:53:\"https://downloads.wordpress.org/plugin/livereload.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:61:\"https://s.w.org/plugins/geopattern-icon/livereload_bbb6b5.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:64:\"https://ps.w.org/livereload/assets/banner-772x250.png?rev=557360\";}s:11:\"banners_rtl\";a:0:{}}s:23:\"tag-pages/tag-pages.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:23:\"w.org/plugins/tag-pages\";s:4:\"slug\";s:9:\"tag-pages\";s:6:\"plugin\";s:23:\"tag-pages/tag-pages.php\";s:11:\"new_version\";s:5:\"1.0.1\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/tag-pages/\";s:7:\"package\";s:52:\"https://downloads.wordpress.org/plugin/tag-pages.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:62:\"https://ps.w.org/tag-pages/assets/icon-256x256.png?rev=1230755\";s:2:\"1x\";s:54:\"https://ps.w.org/tag-pages/assets/icon.svg?rev=1230755\";s:3:\"svg\";s:54:\"https://ps.w.org/tag-pages/assets/icon.svg?rev=1230755\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:63:\"https://ps.w.org/tag-pages/assets/banner-772x250.png?rev=587213\";}s:11:\"banners_rtl\";a:0:{}}s:46:\"facebook-thumb-fixer/_facebook-thumb-fixer.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:34:\"w.org/plugins/facebook-thumb-fixer\";s:4:\"slug\";s:20:\"facebook-thumb-fixer\";s:6:\"plugin\";s:46:\"facebook-thumb-fixer/_facebook-thumb-fixer.php\";s:11:\"new_version\";s:5:\"1.7.6\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/facebook-thumb-fixer/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/facebook-thumb-fixer.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/facebook-thumb-fixer/assets/icon-256x256.png?rev=1835847\";s:2:\"1x\";s:73:\"https://ps.w.org/facebook-thumb-fixer/assets/icon-128x128.png?rev=1835847\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:75:\"https://ps.w.org/facebook-thumb-fixer/assets/banner-772x250.png?rev=1835847\";}s:11:\"banners_rtl\";a:0:{}}s:41:\"wordpress-importer/wordpress-importer.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:32:\"w.org/plugins/wordpress-importer\";s:4:\"slug\";s:18:\"wordpress-importer\";s:6:\"plugin\";s:41:\"wordpress-importer/wordpress-importer.php\";s:11:\"new_version\";s:5:\"0.6.4\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/wordpress-importer/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/wordpress-importer.0.6.4.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:71:\"https://ps.w.org/wordpress-importer/assets/icon-256x256.png?rev=1908375\";s:2:\"1x\";s:63:\"https://ps.w.org/wordpress-importer/assets/icon.svg?rev=1908375\";s:3:\"svg\";s:63:\"https://ps.w.org/wordpress-importer/assets/icon.svg?rev=1908375\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-importer/assets/banner-772x250.png?rev=547654\";}s:11:\"banners_rtl\";a:0:{}}}}','no'),
('241','_site_transient_timeout_browser_ffcde49684f91e48b5fa8131ea4b68af','1545336507','no'),
('242','_site_transient_browser_ffcde49684f91e48b5fa8131ea4b68af','a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"71.0.3578.80\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}','no'),
('243','_transient_timeout_wpseo-statistics-totals','1544818109','no'),
('244','_transient_wpseo-statistics-totals','a:1:{i:1;a:2:{s:6:\"scores\";a:1:{i:0;a:4:{s:8:\"seo_rank\";s:2:\"na\";s:5:\"label\";s:48:\"Posts <strong>without</strong> a focus keyphrase\";s:5:\"count\";s:1:\"1\";s:4:\"link\";s:100:\"http://foundry-prd:8888/wp-admin/edit.php?post_status=publish&#038;post_type=post&#038;seo_filter=na\";}}s:8:\"division\";a:5:{s:3:\"bad\";i:0;s:2:\"ok\";i:0;s:4:\"good\";i:0;s:2:\"na\";i:1;s:7:\"noindex\";i:0;}}}','no'),
('245','_site_transient_timeout_community-events-d41d8cd98f00b204e9800998ecf8427e','1544774909','no'),
('246','_site_transient_community-events-d41d8cd98f00b204e9800998ecf8427e','a:2:{s:8:\"location\";a:1:{s:2:\"ip\";b:0;}s:6:\"events\";a:2:{i:0;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:46:\"WordPress Office Hours {{{Free Website Help}}}\";s:3:\"url\";s:64:\"https://www.meetup.com/georgetown-tx-wordpress/events/257186688/\";s:6:\"meetup\";s:33:\"Georgetown Texas WordPress Meetup\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/georgetown-tx-wordpress/\";s:4:\"date\";s:19:\"2019-01-02 17:30:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Georgetown, TX, USA\";s:7:\"country\";s:2:\"us\";s:8:\"latitude\";d:30.636534000000001043417796608991920948028564453125;s:9:\"longitude\";d:-97.68000000000000682121026329696178436279296875;}}i:1;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:53:\"Building Gutenberg Blocks with Advanced Custom Fields\";s:3:\"url\";s:64:\"https://www.meetup.com/georgetown-tx-wordpress/events/257186875/\";s:6:\"meetup\";s:33:\"Georgetown Texas WordPress Meetup\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/georgetown-tx-wordpress/\";s:4:\"date\";s:19:\"2019-01-02 18:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Georgetown, TX, USA\";s:7:\"country\";s:2:\"us\";s:8:\"latitude\";d:30.636534000000001043417796608991920948028564453125;s:9:\"longitude\";d:-97.68000000000000682121026329696178436279296875;}}}}','no'),
('247','_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca','1544774909','no'),
('248','_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca','1544774910','no'),
('249','_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca','1544731710','no'),
('250','_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9','1544774910','no'),
('251','_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9','1544774910','no'),
('252','_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9','1544731710','no'),
('253','_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b','1544774910','no'),
('254','_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b','<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2018/12/wordcamp-us-2019-dates-announced/\'>WordCamp US 2019 dates announced</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/interview-with-rachel-cherry-automattic-pledges-to-fund-wpcampus-accessibility-audit-of-gutenberg\'>WPTavern: Interview with Rachel Cherry: Automattic Pledges to Fund WPCampus’ Accessibility Audit of Gutenberg</a></li><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2018/12/wordpress-5-0-1-security-release/\'>Dev Blog: WordPress 5.0.1 Security Release</a></li><li><a class=\'rsswidget\' href=\'https://poststatus.com/matt-mullenweg-on-gutenberg/\'>Post Status: Interview with Matt Mullenweg on Gutenberg, WordPress, and the future</a></li></ul></div>','no');

/* Table structure for table `wp_postmeta` */

DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8;

/* dumping data for table `wp_postmeta` */
INSERT INTO `wp_postmeta` VALUES
('11','12','_edit_last','1'),
('12','12','_wp_page_template','default'),
('13','12','ftf_open_type',''),
('14','12','disable_open_graph',null),
('15','12','_yoast_wpseo_content_score','30'),
('16','12','_edit_lock','1544327438:1'),
('17','14','_edit_last','1'),
('18','14','_wp_page_template','default'),
('19','14','ftf_open_type',''),
('20','14','disable_open_graph',null),
('21','14','_yoast_wpseo_content_score','30'),
('22','14','_edit_lock','1544412290:1'),
('23','16','_edit_last','1'),
('24','16','_wp_page_template','default'),
('25','16','ftf_open_type',''),
('26','16','disable_open_graph',null),
('27','16','_edit_lock','1544327472:1'),
('28','19','_wp_attached_file','2018/12/Photo-on-10-27-18-at-6.15-PM.jpg'),
('29','19','_wp_attachment_metadata','a:5:{s:5:\"width\";i:720;s:6:\"height\";i:480;s:4:\"file\";s:40:\"2018/12/Photo-on-10-27-18-at-6.15-PM.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"Photo-on-10-27-18-at-6.15-PM-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"Photo-on-10-27-18-at-6.15-PM-250x167.jpg\";s:5:\"width\";i:250;s:6:\"height\";i:167;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"Photo-on-10-27-18-at-6.15-PM-700x467.jpg\";s:5:\"width\";i:700;s:6:\"height\";i:467;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"small\";a:4:{s:4:\"file\";s:39:\"Photo-on-10-27-18-at-6.15-PM-120x80.jpg\";s:5:\"width\";i:120;s:6:\"height\";i:80;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom-size\";a:4:{s:4:\"file\";s:40:\"Photo-on-10-27-18-at-6.15-PM-700x200.jpg\";s:5:\"width\";i:700;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:1:{i:0;s:11:\"Photo Booth\";}}}'),
('30','21','_edit_last','1'),
('31','21','_edit_lock','1544343220:1'),
('32','43','_edit_last','1'),
('33','43','_edit_lock','1544337702:1'),
('34','43','_yoast_wpseo_content_score','90'),
('35','43','section_0_title','Community'),
('36','43','_section_0_title','field_5c0cb3e343dcb'),
('37','43','section_0_editor','[row]\r\n[column md=\"6\"]\r\n<img class=\"alignnone size-medium wp-image-19\" src=\"http://localhost:8888/wp-content/uploads/2018/12/Photo-on-10-27-18-at-6.15-PM-250x167.jpg\" alt=\"\" />\r\n[/column]\r\n[column md=\"6\"]\r\n...\r\n[/column]\r\n[/row]'),
('38','43','_section_0_editor','field_5c0cb37355c7e'),
('39','43','section_0_background_image',''),
('40','43','_section_0_background_image','field_5c0cb39d43dc8'),
('41','43','section_0_background_color','#ffffff'),
('42','43','_section_0_background_color','field_5c0cb3ad43dc9'),
('43','43','section_0_contrast','dark'),
('44','43','_section_0_contrast','field_5c0cb3ba43dca'),
('45','43','section','1'),
('46','43','_section','field_5c0cb0dfc0a65'),
('47','44','section_0_title',''),
('48','44','_section_0_title','field_5c0cb3e343dcb'),
('49','44','section_0_editor',''),
('50','44','_section_0_editor','field_5c0cb37355c7e'),
('51','44','section_0_background_image',''),
('52','44','_section_0_background_image','field_5c0cb39d43dc8'),
('53','44','section_0_background_color',''),
('54','44','_section_0_background_color','field_5c0cb3ad43dc9'),
('55','44','section_0_contrast',''),
('56','44','_section_0_contrast','field_5c0cb3ba43dca'),
('57','44','section','1'),
('58','44','_section','field_5c0cb0dfc0a65'),
('59','43','_yoast_wpseo_primary_category',''),
('63','43','client_logo',''),
('64','43','_client_logo','field_5c0cb70695214'),
('65','43','description',''),
('66','43','_description','field_5c0cb72e95215'),
('67','43','section_0_background_type','color'),
('68','43','_section_0_background_type','field_5c0cb54b500a3'),
('69','53','section_0_title',''),
('70','53','_section_0_title','field_5c0cb3e343dcb'),
('71','53','section_0_editor','[row]\r\n[column md=\"6\"]\r\n<img class=\"alignnone size-medium wp-image-19\" src=\"http://localhost:8888/wp-content/uploads/2018/12/Photo-on-10-27-18-at-6.15-PM-250x167.jpg\" alt=\"\" />\r\n[/column]\r\n[column md=\"6\"]\r\n...\r\n[/column]\r\n[/row]'),
('72','53','_section_0_editor','field_5c0cb37355c7e'),
('73','53','section_0_background_image',''),
('74','53','_section_0_background_image','field_5c0cb39d43dc8'),
('75','53','section_0_background_color','#ffffff'),
('76','53','_section_0_background_color','field_5c0cb3ad43dc9'),
('77','53','section_0_contrast','dark'),
('78','53','_section_0_contrast','field_5c0cb3ba43dca'),
('79','53','section','1'),
('80','53','_section','field_5c0cb0dfc0a65'),
('81','53','client_logo',''),
('82','53','_client_logo','field_5c0cb70695214'),
('83','53','description',''),
('84','53','_description','field_5c0cb72e95215'),
('85','53','section_0_background_type','color'),
('86','53','_section_0_background_type','field_5c0cb54b500a3'),
('87','54','section_0_title','Community'),
('88','54','_section_0_title','field_5c0cb3e343dcb'),
('89','54','section_0_editor','[row]\r\n[column md=\"6\"]\r\n<img class=\"alignnone size-medium wp-image-19\" src=\"http://localhost:8888/wp-content/uploads/2018/12/Photo-on-10-27-18-at-6.15-PM-250x167.jpg\" alt=\"\" />\r\n[/column]\r\n[column md=\"6\"]\r\n...\r\n[/column]\r\n[/row]'),
('90','54','_section_0_editor','field_5c0cb37355c7e'),
('91','54','section_0_background_image',''),
('92','54','_section_0_background_image','field_5c0cb39d43dc8'),
('93','54','section_0_background_color','#ffffff'),
('94','54','_section_0_background_color','field_5c0cb3ad43dc9'),
('95','54','section_0_contrast','dark'),
('96','54','_section_0_contrast','field_5c0cb3ba43dca'),
('97','54','section','1'),
('98','54','_section','field_5c0cb0dfc0a65'),
('99','54','client_logo',''),
('100','54','_client_logo','field_5c0cb70695214'),
('101','54','description',''),
('102','54','_description','field_5c0cb72e95215'),
('103','54','section_0_background_type','color'),
('104','54','_section_0_background_type','field_5c0cb54b500a3'),
('105','56','_edit_last','1'),
('106','56','_edit_lock','1544389952:1'),
('107','56','_yoast_wpseo_content_score','90'),
('108','56','client_logo',''),
('109','56','_client_logo','field_5c0cb70695214'),
('110','56','description',''),
('111','56','_description','field_5c0cb72e95215'),
('112','56','section_0_title','Community'),
('113','56','_section_0_title','field_5c0cb3e343dcb'),
('114','56','section_0_background_type','color'),
('115','56','_section_0_background_type','field_5c0cb54b500a3'),
('116','56','section_0_background_color','#1e73be'),
('117','56','_section_0_background_color','field_5c0cb3ad43dc9'),
('118','56','section_0_contrast','dark'),
('119','56','_section_0_contrast','field_5c0cb3ba43dca'),
('120','56','section_0_editor','[row]\r\n[column md=\"6\"]\r\nLeft\r\n[/column]\r\n[column md=\"6\"]\r\nRight\r\n[/column]\r\n[/row]'),
('121','56','_section_0_editor','field_5c0cb37355c7e'),
('122','56','section','1'),
('123','56','_section','field_5c0cb0dfc0a65'),
('124','57','client_logo',''),
('125','57','_client_logo','field_5c0cb70695214'),
('126','57','description',''),
('127','57','_description','field_5c0cb72e95215'),
('128','57','section_0_title','Community'),
('129','57','_section_0_title','field_5c0cb3e343dcb'),
('130','57','section_0_background_type','color'),
('131','57','_section_0_background_type','field_5c0cb54b500a3'),
('132','57','section_0_background_color','#ffffff'),
('133','57','_section_0_background_color','field_5c0cb3ad43dc9'),
('134','57','section_0_contrast','dark'),
('135','57','_section_0_contrast','field_5c0cb3ba43dca'),
('136','57','section_0_editor','[row]\r\n[column md=\"6\"]\r\nLeft\r\n[/column]\r\n[column md=\"6\"]\r\nRight\r\n[/column]\r\n[/row]'),
('137','57','_section_0_editor','field_5c0cb37355c7e'),
('138','57','section','1'),
('139','57','_section','field_5c0cb0dfc0a65'),
('140','56','_yoast_wpseo_primary_category',''),
('141','58','client_logo',''),
('142','58','_client_logo','field_5c0cb70695214'),
('143','58','description',''),
('144','58','_description','field_5c0cb72e95215'),
('145','58','section_0_title','Community'),
('146','58','_section_0_title','field_5c0cb3e343dcb'),
('147','58','section_0_background_type','color'),
('148','58','_section_0_background_type','field_5c0cb54b500a3'),
('149','58','section_0_background_color','#1e73be'),
('150','58','_section_0_background_color','field_5c0cb3ad43dc9'),
('151','58','section_0_contrast','dark'),
('152','58','_section_0_contrast','field_5c0cb3ba43dca'),
('153','58','section_0_editor','[row]\r\n[column md=\"6\"]\r\nLeft\r\n[/column]\r\n[column md=\"6\"]\r\nRight\r\n[/column]\r\n[/row]'),
('154','58','_section_0_editor','field_5c0cb37355c7e'),
('155','58','section','1'),
('156','58','_section','field_5c0cb0dfc0a65'),
('157','56','cover_image','70'),
('158','56','_cover_image','field_5c0cbf396379d'),
('159','56','call_to_actions_0_button','a:3:{s:5:\"title\";s:10:\"Visit Site\";s:3:\"url\";s:40:\"http://localhost:8888/clients/atlassian/\";s:6:\"target\";s:0:\"\";}'),
('160','56','_call_to_actions_0_button','field_5c0cbff2ea9d9'),
('161','56','call_to_actions','1'),
('162','56','_call_to_actions','field_5c0cbfe1ea9d8'),
('163','63','client_logo',''),
('164','63','_client_logo','field_5c0cb70695214'),
('165','63','description',''),
('166','63','_description','field_5c0cb72e95215'),
('167','63','section_0_title','Community'),
('168','63','_section_0_title','field_5c0cb3e343dcb'),
('169','63','section_0_background_type','color'),
('170','63','_section_0_background_type','field_5c0cb54b500a3'),
('171','63','section_0_background_color','#1e73be'),
('172','63','_section_0_background_color','field_5c0cb3ad43dc9'),
('173','63','section_0_contrast','dark'),
('174','63','_section_0_contrast','field_5c0cb3ba43dca'),
('175','63','section_0_editor','[row]\r\n[column md=\"6\"]\r\nLeft\r\n[/column]\r\n[column md=\"6\"]\r\nRight\r\n[/column]\r\n[/row]'),
('176','63','_section_0_editor','field_5c0cb37355c7e'),
('177','63','section','1'),
('178','63','_section','field_5c0cb0dfc0a65'),
('179','63','cover_image',''),
('180','63','_cover_image','field_5c0cbf396379d'),
('181','63','call_to_actions_0_button','a:3:{s:5:\"title\";s:10:\"Visit Site\";s:3:\"url\";s:40:\"http://localhost:8888/clients/atlassian/\";s:6:\"target\";s:0:\"\";}'),
('182','63','_call_to_actions_0_button','field_5c0cbff2ea9d9'),
('183','63','call_to_actions','1'),
('184','63','_call_to_actions','field_5c0cbfe1ea9d8'),
('185','65','_wp_attached_file','2018/12/Artboard.png'),
('186','65','_wp_attachment_metadata','a:5:{s:5:\"width\";i:3840;s:6:\"height\";i:1910;s:4:\"file\";s:20:\"2018/12/Artboard.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Artboard-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Artboard-250x124.png\";s:5:\"width\";i:250;s:6:\"height\";i:124;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Artboard-768x382.png\";s:5:\"width\";i:768;s:6:\"height\";i:382;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"Artboard-700x348.png\";s:5:\"width\";i:700;s:6:\"height\";i:348;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"small\";a:4:{s:4:\"file\";s:19:\"Artboard-120x60.png\";s:5:\"width\";i:120;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"custom-size\";a:4:{s:4:\"file\";s:20:\"Artboard-700x200.png\";s:5:\"width\";i:700;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
('187','66','_wp_attached_file','2018/12/alterg-logo.png'),
('188','66','_wp_attachment_metadata','a:5:{s:5:\"width\";i:279;s:6:\"height\";i:70;s:4:\"file\";s:23:\"2018/12/alterg-logo.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"alterg-logo-150x70.png\";s:5:\"width\";i:150;s:6:\"height\";i:70;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"alterg-logo-250x63.png\";s:5:\"width\";i:250;s:6:\"height\";i:63;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"small\";a:4:{s:4:\"file\";s:22:\"alterg-logo-120x30.png\";s:5:\"width\";i:120;s:6:\"height\";i:30;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
('189','64','_edit_last','1'),
('190','64','_yoast_wpseo_content_score','30'),
('191','64','cover_image','65'),
('192','64','_cover_image','field_5c0cbf396379d'),
('193','64','client_logo','66'),
('194','64','_client_logo','field_5c0cb70695214'),
('195','64','description','In 2015 Foundry worked on an exciting healthcare anti-gravity rehabilitation treadmill for professional athletes and stroke victims over the course of 9months.'),
('196','64','_description','field_5c0cb72e95215'),
('197','64','call_to_actions_0_button','a:3:{s:5:\"title\";s:10:\"Visit Site\";s:3:\"url\";s:17:\"http://alterg.com\";s:6:\"target\";s:0:\"\";}'),
('198','64','_call_to_actions_0_button','field_5c0cbff2ea9d9'),
('199','64','call_to_actions','1'),
('200','64','_call_to_actions','field_5c0cbfe1ea9d8'),
('201','64','section',''),
('202','64','_section','field_5c0cb0dfc0a65'),
('203','67','cover_image','65'),
('204','67','_cover_image','field_5c0cbf396379d'),
('205','67','client_logo','66'),
('206','67','_client_logo','field_5c0cb70695214'),
('207','67','description','In 2015 Foundry worked on an exciting healthcare anti-gravity rehabilitation treadmill for professional athletes and stroke victims over the course of 9months.'),
('208','67','_description','field_5c0cb72e95215'),
('209','67','call_to_actions_0_button','a:3:{s:5:\"title\";s:10:\"Visit Site\";s:3:\"url\";s:17:\"http://alterg.com\";s:6:\"target\";s:0:\"\";}'),
('210','67','_call_to_actions_0_button','field_5c0cbff2ea9d9'),
('211','67','call_to_actions','1'),
('212','67','_call_to_actions','field_5c0cbfe1ea9d8'),
('213','67','section',''),
('214','67','_section','field_5c0cb0dfc0a65'),
('215','64','_yoast_wpseo_primary_category',''),
('216','64','_edit_lock','1544340472:1'),
('217','70','_wp_attached_file','2018/12/atlassian.png'),
('218','70','_wp_attachment_metadata','a:5:{s:5:\"width\";i:3840;s:6:\"height\";i:1910;s:4:\"file\";s:21:\"2018/12/atlassian.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"atlassian-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"atlassian-250x124.png\";s:5:\"width\";i:250;s:6:\"height\";i:124;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"atlassian-768x382.png\";s:5:\"width\";i:768;s:6:\"height\";i:382;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"atlassian-700x348.png\";s:5:\"width\";i:700;s:6:\"height\";i:348;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"small\";a:4:{s:4:\"file\";s:20:\"atlassian-120x60.png\";s:5:\"width\";i:120;s:6:\"height\";i:60;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"custom-size\";a:4:{s:4:\"file\";s:21:\"atlassian-700x200.png\";s:5:\"width\";i:700;s:6:\"height\";i:200;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
('219','71','client_logo',''),
('220','71','_client_logo','field_5c0cb70695214'),
('221','71','description',''),
('222','71','_description','field_5c0cb72e95215'),
('223','71','section_0_title','Community'),
('224','71','_section_0_title','field_5c0cb3e343dcb'),
('225','71','section_0_background_type','color'),
('226','71','_section_0_background_type','field_5c0cb54b500a3'),
('227','71','section_0_background_color','#1e73be'),
('228','71','_section_0_background_color','field_5c0cb3ad43dc9'),
('229','71','section_0_contrast','dark'),
('230','71','_section_0_contrast','field_5c0cb3ba43dca'),
('231','71','section_0_editor','[row]\r\n[column md=\"6\"]\r\nLeft\r\n[/column]\r\n[column md=\"6\"]\r\nRight\r\n[/column]\r\n[/row]'),
('232','71','_section_0_editor','field_5c0cb37355c7e'),
('233','71','section','1'),
('234','71','_section','field_5c0cb0dfc0a65'),
('235','71','cover_image','70'),
('236','71','_cover_image','field_5c0cbf396379d'),
('237','71','call_to_actions_0_button','a:3:{s:5:\"title\";s:10:\"Visit Site\";s:3:\"url\";s:40:\"http://localhost:8888/clients/atlassian/\";s:6:\"target\";s:0:\"\";}'),
('238','71','_call_to_actions_0_button','field_5c0cbff2ea9d9'),
('239','71','call_to_actions','1'),
('240','71','_call_to_actions','field_5c0cbfe1ea9d8');

/* Table structure for table `wp_posts` */

DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

/* dumping data for table `wp_posts` */
INSERT INTO `wp_posts` VALUES
('1','1','2018-12-09 02:57:46','2018-12-09 02:57:46','<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->','Hello world!','','publish','open','open','','hello-world','','','2018-12-09 02:57:46','2018-12-09 02:57:46','','0','http://localhost:8888/?p=1','0','post','','1'),
('4','1','2018-12-09 02:58:52','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2018-12-09 02:58:52','0000-00-00 00:00:00','','0','http://localhost:8888/?p=4','0','post','','0'),
('12','1','2018-12-09 03:53:48','2018-12-09 03:53:48','','Meet','','publish','closed','closed','','meet','','','2018-12-09 03:53:48','2018-12-09 03:53:48','','0','http://localhost:8888/?page_id=12','0','page','','0'),
('13','1','2018-12-09 03:53:00','2018-12-09 03:53:00','','Meet','','inherit','closed','closed','','12-revision-v1','','','2018-12-09 03:53:00','2018-12-09 03:53:00','','12','http://localhost:8888/12-revision-v1/','0','revision','','0'),
('14','1','2018-12-09 03:53:48','2018-12-09 03:53:48','','News & Media','','publish','closed','closed','','news-media','','','2018-12-09 03:53:48','2018-12-09 03:53:48','','0','http://localhost:8888/?page_id=14','0','page','','0'),
('15','1','2018-12-09 03:53:11','2018-12-09 03:53:11','','News & Media','','inherit','closed','closed','','14-revision-v1','','','2018-12-09 03:53:11','2018-12-09 03:53:11','','14','http://localhost:8888/14-revision-v1/','0','revision','','0'),
('16','1','2018-12-09 03:53:48','2018-12-09 03:53:48','','About','','publish','closed','closed','','about','','','2018-12-09 03:53:48','2018-12-09 03:53:48','','0','http://localhost:8888/?page_id=16','0','page','','0'),
('17','1','2018-12-09 03:53:24','2018-12-09 03:53:24','','About','','inherit','closed','closed','','16-revision-v1','','','2018-12-09 03:53:24','2018-12-09 03:53:24','','16','http://localhost:8888/16-revision-v1/','0','revision','','0'),
('19','1','2018-12-09 05:54:57','2018-12-09 05:54:57','','Photo on 10-27-18 at 6.15 PM','','inherit','open','closed','','photo-on-10-27-18-at-6-15-pm','','','2018-12-09 06:38:18','2018-12-09 06:38:18','','43','http://localhost:8888/wp-content/uploads/2018/12/Photo-on-10-27-18-at-6.15-PM.jpg','0','attachment','image/jpeg','0'),
('21','1','2018-12-09 06:11:01','2018-12-09 06:11:01','a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:7:\"clients\";}}}s:8:\"position\";s:15:\"acf_after_title\";s:5:\"style\";s:8:\"seamless\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}','Clients','clients','publish','closed','closed','','group_5c0cb0da12872','','','2018-12-09 07:31:00','2018-12-09 07:31:00','','0','http://localhost:8888/?post_type=acf-field-group&#038;p=21','0','acf-field-group','','0'),
('22','1','2018-12-09 06:11:01','2018-12-09 06:11:01','a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:19:\"field_5c0cb3e343dcb\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:3:\"row\";s:12:\"button_label\";s:11:\"Add Section\";}','Section','section','publish','closed','closed','','field_5c0cb0dfc0a65','','','2018-12-09 07:31:00','2018-12-09 07:31:00','','21','http://localhost:8888/?post_type=acf-field&#038;p=22','6','acf-field','','0'),
('28','1','2018-12-09 06:11:04','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2018-12-09 06:11:04','0000-00-00 00:00:00','','0','http://localhost:8888/?post_type=work&p=28','0','work','','0'),
('35','1','2018-12-09 06:17:43','2018-12-09 06:17:43','a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}','Editor','editor','publish','closed','closed','','field_5c0cb37355c7e','','','2018-12-09 06:27:42','2018-12-09 06:27:42','','22','http://localhost:8888/?post_type=acf-field&#038;p=35','8','acf-field','','0'),
('36','1','2018-12-09 06:17:47','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2018-12-09 06:17:47','0000-00-00 00:00:00','','0','http://localhost:8888/?post_type=work&p=36','0','work','','0'),
('37','1','2018-12-09 06:20:02','2018-12-09 06:20:02','a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Title','title','publish','closed','closed','','field_5c0cb3e343dcb','','','2018-12-09 06:20:02','2018-12-09 06:20:02','','22','http://localhost:8888/?post_type=acf-field&p=37','0','acf-field','','0'),
('38','1','2018-12-09 06:20:02','2018-12-09 06:20:02','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:5:\"large\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5c0cb54b500a3\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"image\";}}}}','Background Image','background_image','publish','closed','closed','','field_5c0cb39d43dc8','','','2018-12-09 06:27:42','2018-12-09 06:27:42','','22','http://localhost:8888/?post_type=acf-field&#038;p=38','2','acf-field','','0'),
('39','1','2018-12-09 06:20:02','2018-12-09 06:20:02','a:6:{s:4:\"type\";s:12:\"color_picker\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5c0cb54b500a3\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"color\";}}}}','Background Color','background_color','publish','closed','closed','','field_5c0cb3ad43dc9','','','2018-12-09 06:27:42','2018-12-09 06:27:42','','22','http://localhost:8888/?post_type=acf-field&#038;p=39','3','acf-field','','0'),
('40','1','2018-12-09 06:20:02','2018-12-09 06:20:02','a:13:{s:4:\"type\";s:6:\"select\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:2:{s:4:\"dark\";s:13:\"Dark on white\";s:5:\"white\";s:13:\"White on dark\";}s:13:\"default_value\";a:0:{}s:10:\"allow_null\";i:0;s:8:\"multiple\";i:0;s:2:\"ui\";i:1;s:4:\"ajax\";i:0;s:13:\"return_format\";s:5:\"value\";s:11:\"placeholder\";s:0:\"\";}','Contrast','contrast','publish','closed','closed','','field_5c0cb3ba43dca','','','2018-12-09 06:29:19','2018-12-09 06:29:19','','22','http://localhost:8888/?post_type=acf-field&#038;p=40','4','acf-field','','0'),
('41','1','2018-12-09 06:20:12','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2018-12-09 06:20:12','0000-00-00 00:00:00','','0','http://localhost:8888/?post_type=work&p=41','0','work','','0'),
('42','1','2018-12-09 06:20:28','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2018-12-09 06:20:28','0000-00-00 00:00:00','','0','http://localhost:8888/?post_type=work&p=42','0','work','','0'),
('43','1','2018-12-09 06:21:42','2018-12-09 06:21:42','','Atlassian','','publish','open','open','','atlassian','','','2018-12-09 06:41:16','2018-12-09 06:41:16','','0','http://localhost:8888/?post_type=work&#038;p=43','0','work','','0'),
('44','1','2018-12-09 06:21:42','2018-12-09 06:21:42','','Atlassian','','inherit','closed','closed','','43-revision-v1','','','2018-12-09 06:21:42','2018-12-09 06:21:42','','43','http://localhost:8888/43-revision-v1/','0','revision','','0'),
('45','1','2018-12-09 06:24:32','2018-12-09 06:24:32','a:10:{s:4:\"type\";s:4:\"file\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:7:\"library\";s:3:\"all\";s:8:\"min_size\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5c0cb54b500a3\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"video\";}}}}','Background Video WebM','background_video_webma','publish','closed','closed','','field_5c0cb4c7dd153','','','2018-12-09 06:27:42','2018-12-09 06:27:42','','22','http://localhost:8888/?post_type=acf-field&#038;p=45','5','acf-field','','0'),
('48','1','2018-12-09 06:27:42','2018-12-09 06:27:42','a:13:{s:4:\"type\";s:6:\"select\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:3:{s:5:\"video\";s:5:\"Video\";s:5:\"image\";s:5:\"Image\";s:5:\"color\";s:5:\"Color\";}s:13:\"default_value\";a:0:{}s:10:\"allow_null\";i:0;s:8:\"multiple\";i:0;s:2:\"ui\";i:1;s:4:\"ajax\";i:0;s:13:\"return_format\";s:5:\"value\";s:11:\"placeholder\";s:0:\"\";}','Background Type','background_type','publish','closed','closed','','field_5c0cb54b500a3','','','2018-12-09 06:28:36','2018-12-09 06:28:36','','22','http://localhost:8888/?post_type=acf-field&#038;p=48','1','acf-field','','0'),
('49','1','2018-12-09 06:27:42','2018-12-09 06:27:42','a:10:{s:4:\"type\";s:4:\"file\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:7:\"library\";s:3:\"all\";s:8:\"min_size\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5c0cb54b500a3\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"video\";}}}}','Background Video MP4','background_video_mp4','publish','closed','closed','','field_5c0cb5c4500a4','','','2018-12-09 06:27:42','2018-12-09 06:27:42','','22','http://localhost:8888/?post_type=acf-field&p=49','6','acf-field','','0'),
('50','1','2018-12-09 06:27:42','2018-12-09 06:27:42','a:10:{s:4:\"type\";s:4:\"file\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:7:\"library\";s:3:\"all\";s:8:\"min_size\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5c0cb54b500a3\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:5:\"video\";}}}}','Background Video OGG','background_video_ogg','publish','closed','closed','','field_5c0cb5cc500a5','','','2018-12-09 06:27:42','2018-12-09 06:27:42','','22','http://localhost:8888/?post_type=acf-field&p=50','7','acf-field','','0'),
('51','1','2018-12-09 06:34:24','2018-12-09 06:34:24','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Client logo','client_logo','publish','closed','closed','','field_5c0cb70695214','','','2018-12-09 07:31:00','2018-12-09 07:31:00','','21','http://localhost:8888/?post_type=acf-field&#038;p=51','2','acf-field','','0'),
('52','1','2018-12-09 06:34:24','2018-12-09 06:34:24','a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}','Description','description','publish','closed','closed','','field_5c0cb72e95215','','','2018-12-09 07:31:00','2018-12-09 07:31:00','','21','http://localhost:8888/?post_type=acf-field&#038;p=52','3','acf-field','','0'),
('53','1','2018-12-09 06:38:29','2018-12-09 06:38:29','','Atlassian','','inherit','closed','closed','','43-revision-v1','','','2018-12-09 06:38:29','2018-12-09 06:38:29','','43','http://localhost:8888/43-revision-v1/','0','revision','','0'),
('54','1','2018-12-09 06:38:56','2018-12-09 06:38:56','','Atlassian','','inherit','closed','closed','','43-revision-v1','','','2018-12-09 06:38:56','2018-12-09 06:38:56','','43','http://localhost:8888/43-revision-v1/','0','revision','','0'),
('55','1','2018-12-09 06:50:55','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2018-12-09 06:50:55','0000-00-00 00:00:00','','0','http://localhost:8888/?post_type=clients&p=55','0','clients','','0'),
('56','1','2018-12-09 06:56:57','2018-12-09 06:56:57','','Atlassian','','publish','open','open','','atlassian','','','2018-12-09 07:38:59','2018-12-09 07:38:59','','0','http://localhost:8888/?post_type=clients&#038;p=56','0','clients','','0'),
('57','1','2018-12-09 06:56:57','2018-12-09 06:56:57','','Atlassian','','inherit','closed','closed','','56-revision-v1','','','2018-12-09 06:56:57','2018-12-09 06:56:57','','56','http://localhost:8888/56-revision-v1/','0','revision','','0'),
('58','1','2018-12-09 07:05:42','2018-12-09 07:05:42','','Atlassian','','inherit','closed','closed','','56-revision-v1','','','2018-12-09 07:05:42','2018-12-09 07:05:42','','56','http://localhost:8888/56-revision-v1/','0','revision','','0'),
('59','1','2018-12-09 07:08:00','2018-12-09 07:08:00','a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:5:\"large\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";i:1920;s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}','Cover Image','cover_image','publish','closed','closed','','field_5c0cbf396379d','','','2018-12-09 07:31:00','2018-12-09 07:31:00','','21','http://localhost:8888/?post_type=acf-field&#038;p=59','1','acf-field','','0'),
('61','1','2018-12-09 07:11:40','2018-12-09 07:11:40','a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:19:\"field_5c0cbff2ea9d9\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:3:\"row\";s:12:\"button_label\";s:7:\"Add CTA\";}','Call to Actions','call_to_actions','publish','closed','closed','','field_5c0cbfe1ea9d8','','','2018-12-09 07:31:00','2018-12-09 07:31:00','','21','http://localhost:8888/?post_type=acf-field&#038;p=61','4','acf-field','','0'),
('62','1','2018-12-09 07:11:40','2018-12-09 07:11:40','a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}','Button','button','publish','closed','closed','','field_5c0cbff2ea9d9','','','2018-12-09 07:12:23','2018-12-09 07:12:23','','61','http://localhost:8888/?post_type=acf-field&#038;p=62','0','acf-field','','0'),
('63','1','2018-12-09 07:13:05','2018-12-09 07:13:05','','Atlassian','','inherit','closed','closed','','56-revision-v1','','','2018-12-09 07:13:05','2018-12-09 07:13:05','','56','http://localhost:8888/56-revision-v1/','0','revision','','0'),
('64','1','2018-12-09 07:26:33','2018-12-09 07:26:33','','Alter G','','publish','open','open','','alter-g','','','2018-12-09 07:26:33','2018-12-09 07:26:33','','0','http://localhost:8888/?post_type=clients&#038;p=64','0','clients','','0'),
('65','1','2018-12-09 07:25:29','2018-12-09 07:25:29','','Artboard','','inherit','open','closed','','artboard','','','2018-12-09 07:25:29','2018-12-09 07:25:29','','64','http://localhost:8888/wp-content/uploads/2018/12/Artboard.png','0','attachment','image/png','0'),
('66','1','2018-12-09 07:26:01','2018-12-09 07:26:01','','alterg-logo','','inherit','open','closed','','alterg-logo','','','2018-12-09 07:26:01','2018-12-09 07:26:01','','64','http://localhost:8888/wp-content/uploads/2018/12/alterg-logo.png','0','attachment','image/png','0'),
('67','1','2018-12-09 07:26:33','2018-12-09 07:26:33','','Alter G','','inherit','closed','closed','','64-revision-v1','','','2018-12-09 07:26:33','2018-12-09 07:26:33','','64','http://localhost:8888/64-revision-v1/','0','revision','','0'),
('68','1','2018-12-09 07:31:00','2018-12-09 07:31:00','a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}','Overview','overview','publish','closed','closed','','field_5c0cc48c88a82','','','2018-12-09 07:31:00','2018-12-09 07:31:00','','21','http://localhost:8888/?post_type=acf-field&p=68','0','acf-field','','0'),
('69','1','2018-12-09 07:31:00','2018-12-09 07:31:00','a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}','Sections','overview_copy','publish','closed','closed','','field_5c0cc4a988a83','','','2018-12-09 07:31:00','2018-12-09 07:31:00','','21','http://localhost:8888/?post_type=acf-field&p=69','5','acf-field','','0'),
('70','1','2018-12-09 07:38:52','2018-12-09 07:38:52','','atlassian','','inherit','open','closed','','atlassian-2','','','2018-12-09 07:38:52','2018-12-09 07:38:52','','56','http://localhost:8888/wp-content/uploads/2018/12/atlassian.png','0','attachment','image/png','0'),
('71','1','2018-12-09 07:38:59','2018-12-09 07:38:59','','Atlassian','','inherit','closed','closed','','56-revision-v1','','','2018-12-09 07:38:59','2018-12-09 07:38:59','','56','http://localhost:8888/56-revision-v1/','0','revision','','0'),
('72','1','2018-12-09 08:21:40','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2018-12-09 08:21:40','0000-00-00 00:00:00','','0','http://localhost:8888/?post_type=clients&p=72','0','clients','','0');

/* Table structure for table `wp_term_relationships` */

DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/* dumping data for table `wp_term_relationships` */
INSERT INTO `wp_term_relationships` VALUES
('1','1','0');

/* Table structure for table `wp_term_taxonomy` */

DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/* dumping data for table `wp_term_taxonomy` */
INSERT INTO `wp_term_taxonomy` VALUES
('1','1','category','','0','1'),
('2','2','category','','0','0');

/* Table structure for table `wp_termmeta` */

DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/* Table structure for table `wp_terms` */

DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/* dumping data for table `wp_terms` */
INSERT INTO `wp_terms` VALUES
('1','Uncategorized','uncategorized','0'),
('2','Atlassian','atlassian','0');

/* Table structure for table `wp_usermeta` */

DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

/* dumping data for table `wp_usermeta` */
INSERT INTO `wp_usermeta` VALUES
('1','1','nickname','Bryce'),
('2','1','first_name',''),
('3','1','last_name',''),
('4','1','description',''),
('5','1','rich_editing','true'),
('6','1','syntax_highlighting','true'),
('7','1','comment_shortcuts','false'),
('8','1','admin_color','fresh'),
('9','1','use_ssl','0'),
('10','1','show_admin_bar_front','true'),
('11','1','locale',''),
('12','1','wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
('13','1','wp_user_level','10'),
('14','1','dismissed_wp_pointers','wp496_privacy'),
('15','1','show_welcome_panel','0'),
('16','1','session_tokens','a:2:{s:64:\"3236534a25a8b40f270b01d7a44d935ef5549a37f0723281d223fbb0c9b71972\";a:4:{s:10:\"expiration\";i:1545533930;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36\";s:5:\"login\";i:1544324330;}s:64:\"8324d89aafb16b59ae0782ec41b3c29b629c124bdbe0bde0e4b5f78f6af4e523\";a:4:{s:10:\"expiration\";i:1544904507;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.80 Safari/537.36\";s:5:\"login\";i:1544731707;}}'),
('17','1','wp_user-settings','editor=tinymce&mfold=o&libraryContent=browse&hidetb=1'),
('18','1','wp_user-settings-time','1544324651'),
('19','1','wp_dashboard_quick_press_last_post_id','4'),
('20','1','wp_yoast_notifications','a:2:{i:0;a:2:{s:7:\"message\";s:706:\"<p>The <em>Thumbnail Fixer for Facebook.</em> plugin might cause issues when used in conjunction with Yoast SEO.</p><p>Both Yoast SEO and Thumbnail Fixer for Facebook. create OpenGraph output, which might make Facebook, Twitter, LinkedIn and other social networks use the wrong texts and images when your pages are being shared.<br/><br/><a class=\"button\" href=\"http://foundry-prd:8888/wp-admin/admin.php?page=wpseo_social#top#facebook\">Configure Yoast SEO\'s OpenGraph settings</a></p><a class=\"button button-primary\" href=\"plugins.php?action=deactivate&amp;plugin=facebook-thumb-fixer{2691fc3a186732dee90bb6d80053c48480ba469d57abf6da269ec753bcedac51}2F_facebook-thumb-fixer.php&amp;plugin_status=all&amp;_wpnonce=8ab34ea02a\">Deactivate Thumbnail Fixer for Facebook.</a> \";s:7:\"options\";a:9:{s:4:\"type\";s:5:\"error\";s:2:\"id\";s:47:\"wpseo-conflict-0848240ccaea7d2f28f3f4a50970dd11\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:20:\"wpseo_manage_options\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:1;a:2:{s:7:\"message\";s:166:\"Don\'t miss your crawl errors: <a href=\"http://foundry-prd:8888/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">connect with Google Search Console here</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}'),
('21','1','meta-box-order_dashboard','a:4:{s:6:\"normal\";s:63:\"dashboard_right_now,dashboard_activity,wpseo-dashboard-overview\";s:4:\"side\";s:39:\"dashboard_quick_press,dashboard_primary\";s:7:\"column3\";s:0:\"\";s:7:\"column4\";s:0:\"\";}'),
('22','1','closedpostboxes_dashboard','a:1:{i:0;s:18:\"dashboard_activity\";}'),
('23','1','metaboxhidden_dashboard','a:0:{}'),
('24','1','closedpostboxes_clients','a:6:{i:0;s:12:\"revisionsdiv\";i:1;s:11:\"postexcerpt\";i:2;s:13:\"trackbacksdiv\";i:3;s:16:\"commentstatusdiv\";i:4;s:11:\"commentsdiv\";i:5;s:9:\"authordiv\";}'),
('25','1','metaboxhidden_clients','a:1:{i:0;s:7:\"slugdiv\";}');

/* Table structure for table `wp_users` */

DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/* dumping data for table `wp_users` */
INSERT INTO `wp_users` VALUES
('1','Bryce','$P$BOb7rKkyZQ2PHnWPH9MsADB5gtbW490','bryce','bryce@foundrydigital.co','','2018-12-09 02:57:46','','0','Bryce');

/* Table structure for table `wp_yoast_seo_links` */

DROP TABLE IF EXISTS `wp_yoast_seo_links`;

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/* Table structure for table `wp_yoast_seo_meta` */

DROP TABLE IF EXISTS `wp_yoast_seo_meta`;

CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/* dumping data for table `wp_yoast_seo_meta` */
INSERT INTO `wp_yoast_seo_meta` VALUES
('2','0','0'),
('3','0','0'),
('5','0','0'),
('6','0','0'),
('7','0','0'),
('8','0','0'),
('9','0','0'),
('10','0','0'),
('11','0','0'),
('12','0','0'),
('14','0','0'),
('16','0','0'),
('18','0','0'),
('20','0','0'),
('23','0','0'),
('24','0','0'),
('25','0','0'),
('26','0','0'),
('27','0','0'),
('29','0','0'),
('30','0','0'),
('31','0','0'),
('32','0','0'),
('33','0','0'),
('34','0','0'),
('43','0','0'),
('46','0','0'),
('47','0','0'),
('56','0','0'),
('60','0','0'),
('64','0','0');

